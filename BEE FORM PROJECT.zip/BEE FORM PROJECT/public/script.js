document.getElementById('myForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  const message = document.getElementById('message').value;

  if (password !== confirmPassword) {
    alert('Passwords do not match!');
    return;
  }

  const formData = {
    name: name,
    email: email,
    password: password,
    message: message,
  };

  console.log('Form Data:', formData);

  fetch('http://localhost:3000/store-data', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(formData),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log('Response:', data);
      alert('Form submitted successfully!');
      document.getElementById('myForm').reset();
    })
    .catch((error) => {
      console.error('Error:', error);
      alert('Error submitting the form.');
    });
});
