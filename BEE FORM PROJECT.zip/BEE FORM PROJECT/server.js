const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());

app.use(express.static('public'));

app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/form.html');
});

app.post('/store-data', (req, res) => {
  const { name, email, password, message } = req.body;

  console.log('Received data:', { name, email, password, message });

  if (name && email && password && message) {
    res.status(200).json({ success: true, message: 'Data saved successfully' });
  } else {
    res
      .status(400)
      .json({ success: false, message: 'Missing required fields' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
